<?php

declare(strict_types=1);

namespace sergittos\bedwars\cosmetics\wearable;

use pocketmine\player\Player;
use sergittos\bedwars\BedWarsCore;
use sergittos\bedwars\cosmetics\data\PlayerCosmeticsManager;
use sergittos\bedwars\cosmetics\registry\CosmeticCategory;

/**
 * Single entry point that (re)applies everything the player currently has
 * equipped for Wing/Cape/Hat. Call this on join (after the session has
 * finished loading) and right after any equip/purchase in the cosmetics
 * menu. Pet rendering is handled separately by BedWarsLobby's
 * PetRenderService, since pets only ever exist on the lobby server.
 */
final class WearableRenderService{

    public static function applyAll(Player $player): void{
        if(!$player->isConnected()){
            return;
        }

        $core = BedWarsCore::getInstance();
        $session = $core->getSessionManager()->get($player);
        if($session === null || !$session->isLoaded()){
            return;
        }

        WearableSkinService::captureOriginal($player);

        $mgr = PlayerCosmeticsManager::getInstance();
        $wing = $mgr->getEquipped($player, CosmeticCategory::WING);
        $cape = $mgr->getEquipped($player, CosmeticCategory::CAPE);
        $hat  = $mgr->getEquipped($player, CosmeticCategory::HAT);

        if($wing !== null || $cape !== null){
            WearableSkinService::apply($core, $player, $wing, $cape);
        }else{
            WearableSkinService::restore($player);
        }

        if($hat !== null){
            HatWearService::equip($player, $hat);
        }else{
            HatWearService::clear($player);
        }
    }
}
