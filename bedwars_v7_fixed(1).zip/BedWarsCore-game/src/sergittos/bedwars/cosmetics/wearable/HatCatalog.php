<?php

declare(strict_types=1);

namespace sergittos\bedwars\cosmetics\wearable;

/**
 * Maps a Hat cosmetic's registry key to the Customies item identifier that
 * was registered for it (see the hat item classes under
 * cosmetics/wearable/hats/, registered from BedWarsLobby::onEnable() and
 * BedWarsGame::onEnable()).
 */
final class HatCatalog{

    /** @var array<string, string> */
    private const IDENTIFIERS = [
        "arch_crown" => "snowier:arch_crown",
        "cacti_shoots" => "snowier:cacti_shoots",
        "cowboy" => "snowier:cowboy",
        "cussy" => "snowier:cussy",
        "cussycolor" => "snowier:cussycolor",
        "ember_hat" => "snowier:ember_hat",
        "ent_hat" => "snowier:ent_hat",
        "evoc_hat" => "snowier:evoc_hat",
        "foreigner_hat" => "snowier:foreigner_hat",
        "fungus_hat" => "snowier:fungus_hat",
        "gasmask" => "snowier:gasmask",
        "goldglass" => "snowier:goldglass",
        "miner_hat" => "snowier:miner_hat",
        "mohair" => "snowier:mohair",
        "plag" => "snowier:plag",
        "plaghat" => "snowier:plaghat",
        "hat_birthday_present" => "noxcrew.ft:hat_birthday_present",
        "hat_chicken_jockey" => "noxcrew.ft:hat_chicken_jockey",
        "hat_boombox" => "noxcrew.ft:hat_boombox",
        "hat_crown_cake" => "noxcrew.ft:hat_crown_cake",
        "hat_jester" => "noxcrew.ft:hat_jester",
        "hat_party" => "noxcrew.ft:hat_party",
        "hat_propeller" => "noxcrew.ft:hat_propeller",
    ];

    public static function identifierFor(string $key): ?string{
        return self::$runtime[$key] ?? self::IDENTIFIERS[$key] ?? null;
    }

    /** @return array<string, string> */
    public static function all(): array{
        return self::$runtime + self::IDENTIFIERS;
    }

    /**
     * Registers a new hat purely through data: call this (e.g. from an admin
     * command or a config loader) instead of hand-editing IDENTIFIERS, so
     * hats can be added/removed without touching any PHP class.
     */
    public static function register(string $key, string $identifier): void{
        self::$runtime[$key] = $identifier;
    }

    /** @var array<string, string> hats added at runtime via register(), merged on top of IDENTIFIERS */
    private static array $runtime = [];

    /**
     * Derives the Customies "component tag" (the string every hat's
     * attachable geometry in Hats.zip is keyed by) straight from its
     * Customies identifier, so a single generic item class (see
     * CosmeticHatItem) can register every hat without needing its own
     * per-hat tag hardcoded anywhere. Both identifier families used by the
     * bundled hat pack follow a fixed, reversible naming convention:
     *   "snowier:foo"      -> "snowier_foo"
     *   "noxcrew.ft:bar"   -> "ft.bar"
     */
    public static function componentTagFor(string $identifier): string{
        $pos = strpos($identifier, ":");
        if($pos === false){
            return str_replace([".", ":"], "_", $identifier);
        }
        $namespace = substr($identifier, 0, $pos);
        $key = substr($identifier, $pos + 1);

        return match($namespace){
            "snowier" => "snowier_" . $key,
            "noxcrew.ft" => "ft." . $key,
            default => str_replace(".", "_", $namespace) . "_" . $key,
        };
    }
}
