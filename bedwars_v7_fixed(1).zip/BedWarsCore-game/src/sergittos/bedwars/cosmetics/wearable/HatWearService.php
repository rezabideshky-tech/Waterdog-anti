<?php

declare(strict_types=1);

namespace sergittos\bedwars\cosmetics\wearable;

use customiesdevs\customies\item\CustomiesItemFactory;
use pocketmine\player\Player;
use function class_exists;
use function strtolower;

/**
 * Equips/strips the cosmetic Hat item in the player's helmet slot.
 *
 * A cosmetic hat is always safe to wear now, including while attached to a
 * team in an active game: team identity does NOT live on the helmet alone -
 * GameSettings::apply() always gives every player a team-colored leather
 * chestplate (and leggings/boots too, until an armor upgrade is bought), so
 * teammates/enemies are still told apart at a glance even when the helmet
 * slot itself is holding a cosmetic hat instead of the plain team-colored
 * cap. GameSettings::apply() checks whether the player has a Hat equipped
 * and, if so, skips putting the plain leather cap on the helmet slot in the
 * first place, so there is nothing for a cosmetic hat to fight over there.
 */
final class HatWearService{

    private static function factoryReady(): bool{
        return class_exists(CustomiesItemFactory::class);
    }

    /**
     * Cosmetic hats are always safe to wear - kept as a method (rather than
     * inlining "return true") so callers stay decoupled from that being an
     * always-true check, and so any future genuinely-unsafe state (e.g. a
     * cosmetic-free "vanilla skin" mode) has a single place to hook into.
     */
    public static function isSafeToWear(Player $player): bool{
        return true;
    }

    public static function equip(Player $player, string $hatKey): void{
        if(!self::factoryReady() || !self::isSafeToWear($player)){
            return;
        }

        $identifier = HatCatalog::identifierFor(strtolower($hatKey));
        if($identifier === null){
            return;
        }

        try{
            $item = CustomiesItemFactory::getInstance()->get($identifier);
        }catch(\Throwable){
            return;
        }

        $player->getArmorInventory()->setHelmet($item);
    }

    /**
     * Removes the cosmetic hat, but only if the helmet slot currently holds
     * one of our own cosmetic hat items - never touches real armor.
     */
    public static function clear(Player $player): void{
        if(!self::factoryReady()){
            return;
        }

        $current = $player->getArmorInventory()->getHelmet();
        if($current->isNull()){
            return;
        }

        foreach(HatCatalog::all() as $identifier){
            try{
                $sample = CustomiesItemFactory::getInstance()->get($identifier);
            }catch(\Throwable){
                continue;
            }
            if($current->equals($sample, false, false)){
                $player->getArmorInventory()->setHelmet(\pocketmine\item\VanillaItems::AIR());
                return;
            }
        }
    }
}
