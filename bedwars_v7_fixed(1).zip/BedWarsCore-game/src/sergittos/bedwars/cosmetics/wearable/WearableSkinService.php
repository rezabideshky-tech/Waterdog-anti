<?php

declare(strict_types=1);

namespace sergittos\bedwars\cosmetics\wearable;

use pocketmine\entity\Skin;
use pocketmine\player\Player;
use pocketmine\plugin\Plugin;
use function extension_loaded;
use function file_get_contents;
use function file_exists;
use function getimagesize;
use function imagecreatefrompng;
use function imagedestroy;
use function imagecolorat;
use function imagecopyresampled;
use function imagecreatetruecolor;
use function imagesavealpha;
use function imagealphablending;
use function imagecolorallocatealpha;
use function chr;
use function strtolower;

/**
 * Builds and applies the player's visual skin (base skin + optional wing
 * geometry/texture overlay + optional cape) for the Wing and Cape cosmetic
 * categories. Ported from the CustomWing / TGCapes plugins the server owner
 * supplied, adapted to read from BedWarsCore's own resources and to work
 * from an in-memory "original skin" snapshot instead of files on disk, so
 * nothing here ever touches the player's real account skin.
 *
 * Requires the `gd` PHP extension (same requirement the original wing/cape
 * plugins had). If it's missing, wing/cape rendering is skipped silently
 * after a single warning - everything else in the cosmetics system keeps
 * working normally.
 */
final class WearableSkinService{

    /** @var array<string, Skin> keyed by player raw username (lowercase) */
    private static array $originalSkins = [];

    /** @var array<string, array{0:string,1:string,2:bool,3:array<int,array>}> wing key => [geometry identifier, geometry json data, isFullBodyModel, wing bones], cached */
    private static array $wingGeometryCache = [];

    /** @var array<string, string> cape key => raw cape byte string, cached */
    private static array $capeByteCache = [];

    private static bool $gdWarned = false;

    public static function hasGd(): bool{
        if(extension_loaded("gd")){
            return true;
        }
        if(!self::$gdWarned){
            self::$gdWarned = true;
        }
        return false;
    }

    /**
     * Must be called once, as early as possible after a player joins and
     * before any wearable is applied to them, so we always have their real
     * skin to composite on top of / restore to later.
     */
    public static function captureOriginal(Player $player): void{
        $key = strtolower($player->getName());
        if(!isset(self::$originalSkins[$key])){
            self::$originalSkins[$key] = $player->getSkin();
        }
    }

    public static function forget(Player $player): void{
        unset(self::$originalSkins[strtolower($player->getName())]);
    }

    /**
     * Applies the given wing/cape combination (either can be null/"none") on
     * top of the player's captured original skin and pushes it to the
     * player + viewers. Safe to call repeatedly (e.g. on every cosmetics
     * equip and on join) - it always rebuilds from the original skin so
     * wing/cape changes never stack on top of each other.
     */
    public static function apply(Plugin $core, Player $player, ?string $wingKey, ?string $capeKey): void{
        if(!self::hasGd()){
            return;
        }
        if(!$player->isConnected()){
            return;
        }

        $key = strtolower($player->getName());
        $base = self::$originalSkins[$key] ?? $player->getSkin();

        $skinData = $base->getSkinData();
        $geometryName = $base->getGeometryName();
        $geometryData = $base->getGeometryData();

        if($wingKey !== null && $wingKey !== "" && strtolower($wingKey) !== "none"){
            $composite = self::compositeWing($core, $wingKey, $skinData, $geometryName, $geometryData);
            if($composite !== null){
                [$skinData, $geometryName, $geometryData] = $composite;
            }
        }

        $capeData = $base->getCapeData();
        if($capeKey !== null && $capeKey !== "" && strtolower($capeKey) !== "none"){
            $cape = self::loadCapeBytes($core, $capeKey);
            if($cape !== null){
                $capeData = $cape;
            }
        }elseif($wingKey !== null && $wingKey !== "" && strtolower($wingKey) !== "none"){
            // Wing equipped without a cape - do not carry over an old cape.
            $capeData = "";
        }

        try{
            $skin = new Skin($base->getSkinId(), $skinData, $capeData, $geometryName, $geometryData);
            $player->setSkin($skin);
            $player->sendSkin();
        }catch(\Throwable $e){
            $core->getLogger()->debug("WearableSkinService: failed to apply skin for " . $player->getName() . ": " . $e->getMessage());
        }
    }

    /**
     * Restores the player's real, original skin (used when both wing and
     * cape are unequipped).
     */
    public static function restore(Player $player): void{
        $key = strtolower($player->getName());
        $base = self::$originalSkins[$key] ?? null;
        if($base === null || !$player->isConnected()){
            return;
        }
        $player->setSkin($base);
        $player->sendSkin();
    }

    /**
     * @return array{0:string,1:string,2:string}|null [skinData, geometryName, geometryData]
     */
    private static function compositeWing(Plugin $core, string $wingKey, string $baseSkinData, string $baseGeometryName, string $baseGeometryData): ?array{
        $wingKey = strtolower($wingKey);
        $dir = $core->getDataFolder() . "wearables/wings/";
        $pngPath = $dir . $wingKey . ".png";
        $jsonPath = $dir . $wingKey . ".json";

        if(!file_exists($pngPath) || !file_exists($jsonPath)){
            return null;
        }

        if(!isset(self::$wingGeometryCache[$wingKey])){
            $geoData = file_get_contents($jsonPath);
            if($geoData === false){
                return null;
            }

            // The geometry identifier the client will actually render is whatever
            // is declared inside the JSON itself (minecraft:geometry[0].description.identifier).
            // These files come from third-party wing model packs and each one uses its
            // own identifier (e.g. "geometry.AngelWhite", "geometry.balrog", ...) - it does
            // NOT follow a "geometry.bw_wing_<key>" naming convention. Sending a geometryName
            // that doesn't match any identifier present in geometryData makes the client
            // unable to resolve the model at all, which renders the player fully invisible
            // (to themselves and to everyone else) instead of just failing to show wings.
            // So we must read the real identifier out of the file rather than assume one.
            $identifier = null;
            $decoded = json_decode($geoData, true);
            if(is_array($decoded) && isset($decoded["minecraft:geometry"][0]["description"]["identifier"]) && is_string($decoded["minecraft:geometry"][0]["description"]["identifier"])){
                $identifier = $decoded["minecraft:geometry"][0]["description"]["identifier"];
            }
            if($identifier === null){
                // Malformed/unexpected geometry file - fall back to the old assumed name
                // rather than silently breaking, but this should not normally happen.
                $identifier = "geometry.bw_wing_" . $wingKey;
                $core->getLogger()->debug("WearableSkinService: wing geometry '$wingKey' has no readable identifier, falling back to '$identifier'");
            }

            // Some wing packs (soaring_heart, kraken_tentacles, cuddle_bear,
            // axolotl_plush, ...) are authored as a "backBling"-only
            // attachment: their geometry file contains ONLY the decorative
            // bones (backBling/heart/zip/... etc, all anchored under
            // root/waist/body) and never defines a head/arms/legs bone at
            // all. That's fine for a real backpack-attachable item, but
            // this service sends the geometry as the player's *entire*
            // body model (see apply()) - a model missing head/arm/leg bones
            // makes the client unable to render the player's body at all,
            // so the player (and anyone looking at them) sees no skin,
            // just the tiny decoration floating on its own. Full wing packs
            // (devil, robotic, angelwhite, ...) don't have this problem
            // because they already ship a complete body + wings in one
            // file. We tell the two apart by whether a "head" bone exists.
            $wingBones = [];
            if(is_array($decoded) && isset($decoded["minecraft:geometry"][0]["bones"]) && is_array($decoded["minecraft:geometry"][0]["bones"])){
                $wingBones = $decoded["minecraft:geometry"][0]["bones"];
            }
            $isFullBody = self::bonesIncludeHead($wingBones);

            self::$wingGeometryCache[$wingKey] = [$identifier, $geoData, $isFullBody, $wingBones];
        }
        [$geometryName, $geometryData, $isFullBody, $wingBones] = self::$wingGeometryCache[$wingKey];

        if(!$isFullBody){
            // Backpack-only attachment: graft its decoration bones onto the
            // player's own (real) body skeleton instead of replacing the
            // whole model, so the body keeps rendering normally with the
            // decoration attached to it - exactly like the full wing packs
            // already do, just built dynamically instead of pre-authored.
            $merged = self::buildBackBlingGeometry($wingKey, $wingBones, $baseGeometryName, $baseGeometryData);
            if($merged !== null){
                [$geometryName, $geometryData] = $merged;
            }
        }

        $size = getimagesize($pngPath);
        if($size === false){
            return null;
        }
        [$w, $h] = $size;

        // The base skin byte length tells us its resolution (64x32, 64x64 or 128x128 RGBA).
        $pixelCount = (int) (strlen($baseSkinData) / 4);
        if($pixelCount === 64 * 32){
            $skinW = 64; $skinH = 32;
        }elseif($pixelCount === 64 * 64){
            $skinW = 64; $skinH = 64;
        }elseif($pixelCount === 128 * 128){
            $skinW = 128; $skinH = 128;
        }else{
            $skinW = 64; $skinH = 64;
        }

        $overlay = @imagecreatefrompng($pngPath);
        if($overlay === false){
            return null;
        }

        $resized = imagecreatetruecolor($skinW, $skinH);
        imagealphablending($resized, false);
        imagesavealpha($resized, true);
        $transparent = imagecolorallocatealpha($resized, 0, 0, 0, 127);
        imagecolortransparent($resized, $transparent);
        imagefill($resized, 0, 0, $transparent);
        imagecopyresampled($resized, $overlay, 0, 0, 0, 0, $skinW, $skinH, $w, $h);
        imagedestroy($overlay);

        $bytes = "";
        for($y = 0; $y < $skinH; $y++){
            for($x = 0; $x < $skinW; $x++){
                $i = ($y * $skinW + $x) * 4;
                $baseR = $i < strlen($baseSkinData) ? ord($baseSkinData[$i]) : 0;
                $baseG = $i + 1 < strlen($baseSkinData) ? ord($baseSkinData[$i + 1]) : 0;
                $baseB = $i + 2 < strlen($baseSkinData) ? ord($baseSkinData[$i + 2]) : 0;
                $baseA = $i + 3 < strlen($baseSkinData) ? ord($baseSkinData[$i + 3]) : 0;

                $rgba = imagecolorat($resized, $x, $y);
                $a = ($rgba >> 24) & 0x7F;
                $r = ($rgba >> 16) & 0xFF;
                $g = ($rgba >> 8) & 0xFF;
                $b = $rgba & 0xFF;
                $alpha = 127 - $a; // gd alpha is inverted (0 opaque .. 127 transparent)

                if($alpha > 10){
                    $bytes .= chr($r) . chr($g) . chr($b) . chr((int) (($alpha / 127) * 255));
                }else{
                    $bytes .= chr($baseR) . chr($baseG) . chr($baseB) . chr($baseA);
                }
            }
        }
        imagedestroy($resized);

        return [$bytes, $geometryName, $geometryData];
    }

    /**
     * Builds a full player geometry for a "backBling"-only wing pack by
     * grafting its decoration bones (backBling and everything chained
     * under it) onto a real head/arms/legs skeleton, so the body keeps
     * rendering instead of the client silently giving up on the whole
     * model. Prefers the player's own captured geometry as that skeleton
     * (so their real proportions/arm-width are kept) and only falls back
     * to a built-in standard humanoid skeleton if the player's own
     * geometry couldn't be read - which should not normally happen since
     * the client always sends a full geometry for every skin.
     *
     * @param array<int,array> $decorationBones the wing file's own bones array
     * @return array{0:string,1:string}|null [geometryName, geometryData]
     */
    private static function buildBackBlingGeometry(string $wingKey, array $decorationBones, string $baseGeometryName, string $baseGeometryData): ?array{
        $templateBones = self::extractBonesByIdentifier($baseGeometryData, $baseGeometryName);
        if($templateBones === null || !self::bonesIncludeHead($templateBones)){
            $templateBones = self::standardHumanoidBones();
        }

        // root/waist/body already exist in the template at the same pivots
        // every vanilla-shaped player skeleton uses - keep the template's
        // copies (they carry the real body/torso cube) and only bring over
        // the wing's own decoration bones.
        $skip = ["root" => true, "waist" => true, "body" => true];
        $extra = [];
        foreach($decorationBones as $bone){
            $name = is_array($bone) && isset($bone["name"]) && is_string($bone["name"]) ? strtolower($bone["name"]) : "";
            if($name === "" || isset($skip[$name])){
                continue;
            }
            $extra[] = $bone;
        }

        if($extra === []){
            // Nothing decorative to actually attach - not worth swapping
            // the player's geometry out for no visible benefit.
            return null;
        }

        $mergedBones = [];
        foreach($templateBones as $bone){
            $mergedBones[] = $bone;
        }
        foreach($extra as $bone){
            $mergedBones[] = $bone;
        }

        $identifier = "geometry.bw_backbling_" . $wingKey;
        $geometry = [
            "format_version" => "1.12.0",
            "minecraft:geometry" => [
                [
                    "description" => [
                        "identifier" => $identifier,
                        "texture_width" => 64,
                        "texture_height" => 64,
                        "visible_bounds_width" => 3,
                        "visible_bounds_height" => 3.5,
                        "visible_bounds_offset" => [0, 1.25, 0]
                    ],
                    "bones" => $mergedBones
                ]
            ]
        ];

        $encoded = json_encode($geometry);
        if($encoded === false){
            return null;
        }

        return [$identifier, $encoded];
    }

    /**
     * @return array<int,array>|null the bones array of the geometry entry
     *         matching $identifier inside $geometryData, or of the first
     *         entry if none matches; null if $geometryData is empty/unparsable.
     */
    private static function extractBonesByIdentifier(string $geometryData, string $identifier): ?array{
        if($geometryData === ""){
            return null;
        }
        $decoded = json_decode($geometryData, true);
        if(!is_array($decoded) || !isset($decoded["minecraft:geometry"]) || !is_array($decoded["minecraft:geometry"])){
            return null;
        }
        foreach($decoded["minecraft:geometry"] as $entry){
            if(!is_array($entry) || !isset($entry["bones"]) || !is_array($entry["bones"])){
                continue;
            }
            $entryId = $entry["description"]["identifier"] ?? null;
            if($entryId === $identifier){
                return $entry["bones"];
            }
        }
        $first = $decoded["minecraft:geometry"][0]["bones"] ?? null;
        return is_array($first) ? $first : null;
    }

    /**
     * @param array<int,array> $bones
     */
    private static function bonesIncludeHead(array $bones): bool{
        foreach($bones as $bone){
            if(is_array($bone) && isset($bone["name"]) && is_string($bone["name"]) && strtolower($bone["name"]) === "head"){
                return true;
            }
        }
        return false;
    }

    /**
     * Standard Bedrock player skeleton (slim-arm proportions), 64x64 UV
     * layout. Last-resort fallback only - see buildBackBlingGeometry().
     *
     * @return array<int,array>
     */
    private static function standardHumanoidBones(): array{
        return [
            ["name" => "root", "pivot" => [0, 0, 0]],
            ["name" => "waist", "parent" => "root", "pivot" => [0, 12, 0]],
            ["name" => "body", "parent" => "waist", "pivot" => [0, 24, 0], "cubes" => [["origin" => [-4, 12, -2], "size" => [8, 12, 4], "uv" => [16, 16]]]],
            ["name" => "head", "parent" => "body", "pivot" => [0, 24, 0], "cubes" => [["origin" => [-4, 24, -4], "size" => [8, 8, 8], "uv" => [0, 0]]]],
            ["name" => "hat", "parent" => "head", "pivot" => [0, 24, 0], "cubes" => [["origin" => [-4, 24, -4], "size" => [8, 8, 8], "inflate" => 0.5, "uv" => [32, 0]]]],
            ["name" => "rightArm", "parent" => "body", "pivot" => [-5, 22, 0], "cubes" => [["origin" => [-7, 12, -2], "size" => [3, 12, 4], "uv" => [40, 16]]]],
            ["name" => "rightSleeve", "parent" => "rightArm", "pivot" => [-5, 22, 0], "cubes" => [["origin" => [-7, 12, -2], "size" => [3, 12, 4], "inflate" => 0.25, "uv" => [40, 32]]]],
            ["name" => "rightItem", "parent" => "rightArm", "pivot" => [-6, 15, 1]],
            ["name" => "leftArm", "parent" => "body", "pivot" => [5, 22, 0], "mirror" => true, "cubes" => [["origin" => [4, 12, -2], "size" => [3, 12, 4], "uv" => [32, 48]]]],
            ["name" => "leftSleeve", "parent" => "leftArm", "pivot" => [5, 22, 0], "mirror" => true, "cubes" => [["origin" => [4, 12, -2], "size" => [3, 12, 4], "inflate" => 0.25, "uv" => [48, 48]]]],
            ["name" => "leftItem", "parent" => "leftArm", "pivot" => [6, 15, 1]],
            ["name" => "jacket", "parent" => "body", "pivot" => [0, 24, 0], "cubes" => [["origin" => [-4, 12, -2], "size" => [8, 12, 4], "inflate" => 0.25, "uv" => [16, 32]]]],
            ["name" => "rightLeg", "parent" => "root", "pivot" => [-1.9, 12, 0], "cubes" => [["origin" => [-3.9, 0, -2], "size" => [4, 12, 4], "uv" => [0, 16]]]],
            ["name" => "rightPants", "parent" => "rightLeg", "pivot" => [-1.9, 12, 0], "cubes" => [["origin" => [-3.9, 0, -2], "size" => [4, 12, 4], "inflate" => 0.25, "uv" => [0, 32]]]],
            ["name" => "leftLeg", "parent" => "root", "pivot" => [1.9, 12, 0], "mirror" => true, "cubes" => [["origin" => [-0.1, 0, -2], "size" => [4, 12, 4], "uv" => [16, 48]]]],
            ["name" => "leftPants", "parent" => "leftLeg", "pivot" => [1.9, 12, 0], "mirror" => true, "cubes" => [["origin" => [-0.1, 0, -2], "size" => [4, 12, 4], "inflate" => 0.25, "uv" => [0, 48]]]],
            ["name" => "cape", "parent" => "body", "pivot" => [0, 24, -2], "cubes" => [["origin" => [-4, 8, -1], "size" => [8, 16, 1], "uv" => [0, 0]]]]
        ];
    }

    private static function loadCapeBytes(Plugin $core, string $capeKey): ?string{
        if(isset(self::$capeByteCache[$capeKey])){
            return self::$capeByteCache[$capeKey];
        }

        $path = $core->getDataFolder() . "wearables/capes/" . $capeKey . ".png";
        if(!file_exists($path)){
            return null;
        }

        $size = getimagesize($path);
        if($size === false){
            return null;
        }
        $img = @imagecreatefrompng($path);
        if($img === false){
            return null;
        }

        $bytes = "";
        $h = $size[1];
        for($y = 0; $y < $h; $y++){
            for($x = 0; $x < 64; $x++){
                $rgba = @imagecolorat($img, $x, $y);
                $a = ((~((int) ($rgba >> 24))) << 1) & 0xff;
                $r = ($rgba >> 16) & 0xff;
                $g = ($rgba >> 8) & 0xff;
                $b = $rgba & 0xff;
                $bytes .= chr($r) . chr($g) . chr($b) . chr($a);
            }
        }
        imagedestroy($img);

        self::$capeByteCache[$capeKey] = $bytes;
        return $bytes;
    }
}
