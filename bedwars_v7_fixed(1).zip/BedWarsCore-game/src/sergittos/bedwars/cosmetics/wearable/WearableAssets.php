<?php

declare(strict_types=1);

namespace sergittos\bedwars\cosmetics\wearable;

use function closedir;
use function copy;
use function is_dir;
use function mkdir;
use function opendir;
use function readdir;
use function rtrim;

final class WearableAssets{

    public static function install(string $pluginFile, string $dataFolder): void{
        $src = rtrim($pluginFile, "/") . "/resources/wearables";
        $dst = rtrim($dataFolder, "/") . "/wearables";
        if(!is_dir($src)){
            return;
        }
        self::copyRecursive($src, $dst);
    }

    private static function copyRecursive(string $src, string $dst): void{
        if(!is_dir($dst)){
            mkdir($dst, 0777, true);
        }
        $dir = opendir($src);
        if($dir === false){
            return;
        }
        while(($file = readdir($dir)) !== false){
            if($file === "." || $file === ".."){
                continue;
            }
            $srcPath = $src . "/" . $file;
            $dstPath = $dst . "/" . $file;
            if(is_dir($srcPath)){
                self::copyRecursive($srcPath, $dstPath);
            }else{
                copy($srcPath, $dstPath);
            }
        }
        closedir($dir);
    }
}
