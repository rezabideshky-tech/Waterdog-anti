<?php

declare(strict_types=1);

namespace sergittos\bedwars\cosmetics\registry;

enum CosmeticRarity: string{
    case COMMON = "Common";
    case RARE = "Rare";
    case LEGENDARY = "Legendary";

    public function color(): string{
        return match($this){
            self::COMMON => "§7",
            self::RARE => "§b",
            self::LEGENDARY => "§6",
        };
    }
}