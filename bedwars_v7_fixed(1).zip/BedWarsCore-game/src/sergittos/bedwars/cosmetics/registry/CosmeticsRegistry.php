<?php

declare(strict_types=1);

namespace sergittos\bedwars\cosmetics\registry;

use function array_values;

final class CosmeticsRegistry{

    private static ?CosmeticsRegistry $instance = null;

    /** @var array<string, array<string, CosmeticDefinition>> */
    private array $items = [];

    public static function getInstance(): CosmeticsRegistry{
        return self::$instance ??= new CosmeticsRegistry();
    }

    public function initDefaults(): void{
        $this->items = [];

        $this->add(new CosmeticDefinition("snowflake", CosmeticCategory::FINAL_KILL_EFFECT, "Snowflake", 8600, CosmeticRarity::RARE, "textures/items/snowball"));
        $this->add(new CosmeticDefinition("critical_hit", CosmeticCategory::FINAL_KILL_EFFECT, "Critical Hit", 9900, CosmeticRarity::RARE, "textures/items/diamond_sword"));
        $this->add(new CosmeticDefinition("water_splash", CosmeticCategory::FINAL_KILL_EFFECT, "Water Splash", 11100, CosmeticRarity::RARE, "textures/items/potion_bottle_splash"));
        $this->add(new CosmeticDefinition("happy_villager", CosmeticCategory::FINAL_KILL_EFFECT, "Happy Villager", 12400, CosmeticRarity::RARE, "textures/items/emerald"));
        $this->add(new CosmeticDefinition("enchant", CosmeticCategory::FINAL_KILL_EFFECT, "Enchant", 13700, CosmeticRarity::RARE, "textures/items/book_enchanted"));
        $this->add(new CosmeticDefinition("portal", CosmeticCategory::FINAL_KILL_EFFECT, "Portal", 15000, CosmeticRarity::LEGENDARY, "textures/blocks/portal"));
        $this->add(new CosmeticDefinition("flame", CosmeticCategory::FINAL_KILL_EFFECT, "Flame", 6000, CosmeticRarity::COMMON, "textures/items/fire_charge"));
        $this->add(new CosmeticDefinition("hearts", CosmeticCategory::FINAL_KILL_EFFECT, "Hearts", 7300, CosmeticRarity::COMMON, "textures/items/apple_golden"));

        $this->add(new CosmeticDefinition("flame", CosmeticCategory::BED_BREAK_EFFECT, "Flame", 11000, CosmeticRarity::COMMON, "textures/items/fire_charge"));
        $this->add(new CosmeticDefinition("hearts", CosmeticCategory::BED_BREAK_EFFECT, "Hearts", 11700, CosmeticRarity::COMMON, "textures/items/apple_golden"));
        $this->add(new CosmeticDefinition("snowflake", CosmeticCategory::BED_BREAK_EFFECT, "Snowflake", 12400, CosmeticRarity::RARE, "textures/items/snowball"));
        $this->add(new CosmeticDefinition("shatter", CosmeticCategory::BED_BREAK_EFFECT, "Shatter", 13100, CosmeticRarity::RARE, "textures/blocks/glass"));
        $this->add(new CosmeticDefinition("water_splash", CosmeticCategory::BED_BREAK_EFFECT, "Water Splash", 13900, CosmeticRarity::RARE, "textures/items/potion_bottle_splash"));
        $this->add(new CosmeticDefinition("happy_villager", CosmeticCategory::BED_BREAK_EFFECT, "Happy Villager", 14600, CosmeticRarity::RARE, "textures/items/emerald"));
        $this->add(new CosmeticDefinition("enchant", CosmeticCategory::BED_BREAK_EFFECT, "Enchant", 15300, CosmeticRarity::RARE, "textures/items/book_enchanted"));
        $this->add(new CosmeticDefinition("portal", CosmeticCategory::BED_BREAK_EFFECT, "Portal", 16000, CosmeticRarity::LEGENDARY, "textures/blocks/portal"));

        $this->add(new CosmeticDefinition("skeleton", CosmeticCategory::DEATH_CRY, "Skeleton", 6000, CosmeticRarity::COMMON, "textures/items/bone"));
        $this->add(new CosmeticDefinition("blaze", CosmeticCategory::DEATH_CRY, "Blaze", 6900, CosmeticRarity::COMMON, "textures/items/blaze_rod"));
        $this->add(new CosmeticDefinition("cat_meow", CosmeticCategory::DEATH_CRY, "Cat Meow", 7700, CosmeticRarity::COMMON, "textures/items/fish_salmon_raw"));
        $this->add(new CosmeticDefinition("pling", CosmeticCategory::DEATH_CRY, "Pling", 8600, CosmeticRarity::COMMON, "textures/items/record_11"));
        $this->add(new CosmeticDefinition("ghast", CosmeticCategory::DEATH_CRY, "Ghast", 10300, CosmeticRarity::RARE, "textures/items/ghast_tear"));
        $this->add(new CosmeticDefinition("explosion", CosmeticCategory::DEATH_CRY, "Explosion", 11100, CosmeticRarity::RARE, "textures/items/gunpowder"));
        $this->add(new CosmeticDefinition("villager_no", CosmeticCategory::DEATH_CRY, "Villager", 9400, CosmeticRarity::COMMON, "textures/items/emerald"));
        $this->add(new CosmeticDefinition("dragon", CosmeticCategory::DEATH_CRY, "Dragon", 12000, CosmeticRarity::LEGENDARY, "textures/items/dragon_breath"));

        $this->add(new CosmeticDefinition("orb", CosmeticCategory::KILL_SOUND, "Orb", 6000, CosmeticRarity::COMMON, "textures/items/experience_bottle"));
        $this->add(new CosmeticDefinition("levelup", CosmeticCategory::KILL_SOUND, "Level Up", 7500, CosmeticRarity::COMMON, "textures/items/experience_bottle"));
        $this->add(new CosmeticDefinition("anvil", CosmeticCategory::KILL_SOUND, "Anvil", 10500, CosmeticRarity::RARE, "textures/blocks/anvil"));
        $this->add(new CosmeticDefinition("thunder", CosmeticCategory::KILL_SOUND, "Thunder", 12000, CosmeticRarity::RARE, "textures/items/nether_star"));
        $this->add(new CosmeticDefinition("pling", CosmeticCategory::KILL_SOUND, "Pling", 9000, CosmeticRarity::COMMON, "textures/blocks/noteblock"));

        $this->add(new CosmeticDefinition("savage", CosmeticCategory::KILL_MESSAGE, "Savage", 7000, CosmeticRarity::COMMON, "textures/items/name_tag"));
        $this->add(new CosmeticDefinition("royal", CosmeticCategory::KILL_MESSAGE, "Royal Decree", 8600, CosmeticRarity::RARE, "textures/items/name_tag"));
        $this->add(new CosmeticDefinition("assassin", CosmeticCategory::KILL_MESSAGE, "Silent Blade", 10200, CosmeticRarity::RARE, "textures/items/name_tag"));
        $this->add(new CosmeticDefinition("warlord", CosmeticCategory::KILL_MESSAGE, "Warlord", 11800, CosmeticRarity::RARE, "textures/items/name_tag"));
        $this->add(new CosmeticDefinition("champion", CosmeticCategory::KILL_MESSAGE, "Champion", 13400, CosmeticRarity::LEGENDARY, "textures/items/name_tag"));
        $this->add(new CosmeticDefinition("phantom", CosmeticCategory::KILL_MESSAGE, "Phantom", 15000, CosmeticRarity::LEGENDARY, "textures/items/name_tag"));

        $this->add(new CosmeticDefinition("victory_flame", CosmeticCategory::WIN_EFFECT, "Victory Flame", 6000, CosmeticRarity::COMMON, "textures/items/fire_charge"));
        $this->add(new CosmeticDefinition("victory_hearts", CosmeticCategory::WIN_EFFECT, "Victory Hearts", 7000, CosmeticRarity::COMMON, "textures/items/apple_golden"));
        $this->add(new CosmeticDefinition("victory_enchant", CosmeticCategory::WIN_EFFECT, "Arcane Triumph", 9000, CosmeticRarity::RARE, "textures/items/book_enchanted"));
        $this->add(new CosmeticDefinition("victory_portal", CosmeticCategory::WIN_EFFECT, "Dimensional Crown", 12000, CosmeticRarity::LEGENDARY, "textures/blocks/portal"));
        $this->add(new CosmeticDefinition("victory_critical", CosmeticCategory::WIN_EFFECT, "Champion Burst", 10000, CosmeticRarity::RARE, "textures/items/nether_star"));
        $this->add(new CosmeticDefinition("victory_snowflake", CosmeticCategory::WIN_EFFECT, "Victory Snowflake", 8000, CosmeticRarity::COMMON, "textures/items/snowball"));
        $this->add(new CosmeticDefinition("victory_happy", CosmeticCategory::WIN_EFFECT, "Victory Villager", 11000, CosmeticRarity::RARE, "textures/items/emerald"));

        $this->add(new CosmeticDefinition("trail_flame", CosmeticCategory::PROJECTILE_TRAIL, "Flame Trail", 9000, CosmeticRarity::COMMON, "textures/items/fire_charge"));
        $this->add(new CosmeticDefinition("trail_hearts", CosmeticCategory::PROJECTILE_TRAIL, "Hearts Trail", 11500, CosmeticRarity::COMMON, "textures/items/apple_golden"));
        $this->add(new CosmeticDefinition("trail_portal", CosmeticCategory::PROJECTILE_TRAIL, "Portal Trail", 14000, CosmeticRarity::RARE, "textures/blocks/portal"));
        $this->add(new CosmeticDefinition("trail_enchant", CosmeticCategory::PROJECTILE_TRAIL, "Enchant Trail", 16500, CosmeticRarity::RARE, "textures/items/book_enchanted"));
        $this->add(new CosmeticDefinition("trail_critical", CosmeticCategory::PROJECTILE_TRAIL, "Critical Trail", 19000, CosmeticRarity::RARE, "textures/items/diamond_sword"));

        $this->add(new CosmeticDefinition("hooray", CosmeticCategory::VICTORY_DANCE, "Hooray!", 15000, CosmeticRarity::COMMON, "textures/items/nether_star"));
        $this->add(new CosmeticDefinition("groovin", CosmeticCategory::VICTORY_DANCE, "Groovin'", 15800, CosmeticRarity::COMMON, "textures/items/record_13"));
        $this->add(new CosmeticDefinition("cheer_routine", CosmeticCategory::VICTORY_DANCE, "Cheer Routine", 16700, CosmeticRarity::RARE, "textures/items/record_cat"));
        $this->add(new CosmeticDefinition("salsa", CosmeticCategory::VICTORY_DANCE, "Salsa Dancing", 17500, CosmeticRarity::RARE, "textures/items/record_mall"));
        $this->add(new CosmeticDefinition("breakdance", CosmeticCategory::VICTORY_DANCE, "Breakdance", 18300, CosmeticRarity::RARE, "textures/items/record_blocks"));
        $this->add(new CosmeticDefinition("victory_cheer", CosmeticCategory::VICTORY_DANCE, "Victory Cheer", 19200, CosmeticRarity::LEGENDARY, "textures/items/nether_star"));
        $this->add(new CosmeticDefinition("sonic_spin", CosmeticCategory::VICTORY_DANCE, "Champion Spin", 20000, CosmeticRarity::LEGENDARY, "textures/items/record_far"));

        // --- Pets (lobby-only wearable cosmetics) ---
        $this->add(new CosmeticDefinition("babydragon", CosmeticCategory::PET, "Baby Dragon", 500000, CosmeticRarity::LEGENDARY, "textures/items/egg"));
        $this->add(new CosmeticDefinition("cubee", CosmeticCategory::PET, "Cubee", 100000, CosmeticRarity::COMMON, "textures/items/egg"));
        $this->add(new CosmeticDefinition("endolotl", CosmeticCategory::PET, "Endolotl", 220000, CosmeticRarity::RARE, "textures/items/egg"));
        $this->add(new CosmeticDefinition("pirateparrot", CosmeticCategory::PET, "Pirate Parrot", 230000, CosmeticRarity::RARE, "textures/items/egg"));
        $this->add(new CosmeticDefinition("pirateship", CosmeticCategory::PET, "Pirate Ship", 480000, CosmeticRarity::LEGENDARY, "textures/items/egg"));
        $this->add(new CosmeticDefinition("witchcat", CosmeticCategory::PET, "Witch Cat", 240000, CosmeticRarity::RARE, "textures/items/egg"));
        $this->add(new CosmeticDefinition("rock", CosmeticCategory::PET, "Rock", 90000, CosmeticRarity::COMMON, "textures/items/egg"));

        // --- Wings / Backbling (worn in lobby and in-game) ---
        // Curated to exactly the set shipped in wings.zip - keep this list
        // and resources/wearables/wings/ in sync (see WearableAssets): any
        // key added here needs a matching {key}.png + {key}.json there, and
        // any key removed here should have its files removed there too.
        $this->add(new CosmeticDefinition("angelkiller", CosmeticCategory::WING, "Angel Killer", 33000, CosmeticRarity::LEGENDARY, "textures/ui/wingsicon/angelkiller"));
        $this->add(new CosmeticDefinition("angelwhite", CosmeticCategory::WING, "Angel White", 34400, CosmeticRarity::LEGENDARY, "textures/ui/wingsicon/angelwhite"));
        $this->add(new CosmeticDefinition("axolotl_plush", CosmeticCategory::WING, "Axolotl Plush", 19000, CosmeticRarity::COMMON, "textures/ui/wingsicon/axolotl_plush_sunflower"));
        $this->add(new CosmeticDefinition("blazingelectro", CosmeticCategory::WING, "Blazing Electro", 24600, CosmeticRarity::RARE, "textures/ui/wingsicon/blazingelectro"));
        $this->add(new CosmeticDefinition("cuddle_bear", CosmeticCategory::WING, "Cuddle Bear", 20400, CosmeticRarity::COMMON, "textures/ui/wingsicon/cuddle_bear_brown"));
        $this->add(new CosmeticDefinition("davinci", CosmeticCategory::WING, "Davinci", 26000, CosmeticRarity::RARE, "textures/ui/wingsicon/davinci"));
        $this->add(new CosmeticDefinition("devil", CosmeticCategory::WING, "Devil", 27400, CosmeticRarity::RARE, "textures/ui/wingsicon/devil"));
        $this->add(new CosmeticDefinition("diamond", CosmeticCategory::WING, "Diamond", 28800, CosmeticRarity::RARE, "textures/ui/wingsicon/diamond"));
        $this->add(new CosmeticDefinition("enderdragon", CosmeticCategory::WING, "Ender Dragon", 35800, CosmeticRarity::LEGENDARY, "textures/ui/wingsicon/enderdragon"));
        $this->add(new CosmeticDefinition("fairy", CosmeticCategory::WING, "Fairy", 21800, CosmeticRarity::COMMON, "textures/ui/wingsicon/fairy"));
        $this->add(new CosmeticDefinition("firedragon", CosmeticCategory::WING, "Fire Dragon", 37200, CosmeticRarity::LEGENDARY, "textures/ui/wingsicon/firedragon"));
        $this->add(new CosmeticDefinition("kraken_tentacles", CosmeticCategory::WING, "Kraken Tentacles", 38600, CosmeticRarity::LEGENDARY, "textures/ui/wingsicon/kraken_tentacles_purple"));
        $this->add(new CosmeticDefinition("monarchbutterfly", CosmeticCategory::WING, "Monarch Butterfly", 23200, CosmeticRarity::COMMON, "textures/ui/wingsicon/monarchbutterfly"));
        $this->add(new CosmeticDefinition("poisondragon", CosmeticCategory::WING, "Poison Dragon", 40000, CosmeticRarity::LEGENDARY, "textures/ui/wingsicon/poisondragon"));
        $this->add(new CosmeticDefinition("robotic", CosmeticCategory::WING, "Robotic", 30200, CosmeticRarity::RARE, "textures/ui/wingsicon/robotic"));
        $this->add(new CosmeticDefinition("soaring_heart", CosmeticCategory::WING, "Soaring Heart", 31600, CosmeticRarity::RARE, "textures/ui/wingsicon/soaring_heart_pink"));

        // --- Capes (worn in lobby and in-game) ---
        // Curated to exactly the set shipped in capes.zip - keep this list
        // and resources/wearables/capes/ in sync (see WearableAssets): any
        // key added here needs a matching {key}.png there, and any key
        // removed here should have its file removed there too.
        $this->add(new CosmeticDefinition("aceee", CosmeticCategory::CAPE, "Aceee", 23800, CosmeticRarity::RARE, "textures/ui/capesicon/aceee"));
        $this->add(new CosmeticDefinition("blue_creeper", CosmeticCategory::CAPE, "Blue Creeper", 14000, CosmeticRarity::COMMON, "textures/ui/capesicon/bluecreeper"));
        $this->add(new CosmeticDefinition("day_dream", CosmeticCategory::CAPE, "Day Dream", 25100, CosmeticRarity::RARE, "textures/ui/capesicon/dream"));
        $this->add(new CosmeticDefinition("demon", CosmeticCategory::CAPE, "Demon", 15200, CosmeticRarity::COMMON, "textures/ui/capesicon/demon"));
        $this->add(new CosmeticDefinition("enderman", CosmeticCategory::CAPE, "Enderman", 26300, CosmeticRarity::RARE, "textures/ui/capesicon/enderman"));
        $this->add(new CosmeticDefinition("eva", CosmeticCategory::CAPE, "Eva", 16500, CosmeticRarity::COMMON, "textures/ui/capesicon/eva"));
        $this->add(new CosmeticDefinition("fire", CosmeticCategory::CAPE, "Fire", 17700, CosmeticRarity::COMMON, "textures/ui/capesicon/fire"));
        $this->add(new CosmeticDefinition("firework", CosmeticCategory::CAPE, "Firework", 18900, CosmeticRarity::COMMON, "textures/ui/capesicon/firework"));
        $this->add(new CosmeticDefinition("iron_golem", CosmeticCategory::CAPE, "Iron Golem", 27500, CosmeticRarity::RARE, "textures/ui/capesicon/irongolem"));
        $this->add(new CosmeticDefinition("orangest", CosmeticCategory::CAPE, "Orangest", 20200, CosmeticRarity::COMMON, "textures/ui/capesicon/orange"));
        $this->add(new CosmeticDefinition("pickaxe", CosmeticCategory::CAPE, "Pickaxe", 30000, CosmeticRarity::LEGENDARY, "textures/ui/capesicon/pickaxe"));
        $this->add(new CosmeticDefinition("red_creeper", CosmeticCategory::CAPE, "Red Creeper", 21400, CosmeticRarity::COMMON, "textures/ui/capesicon/redcreeper"));
        $this->add(new CosmeticDefinition("snake", CosmeticCategory::CAPE, "Snake", 28800, CosmeticRarity::RARE, "textures/ui/capesicon/snake"));
        $this->add(new CosmeticDefinition("turtle", CosmeticCategory::CAPE, "Turtle", 22600, CosmeticRarity::COMMON, "textures/ui/capesicon/turtle"));


        // --- Hats (worn on head, lobby-only during active matches - see HatWearService) ---
        $this->add(new CosmeticDefinition("arch_crown", CosmeticCategory::HAT, "Arch Crown", 400000, CosmeticRarity::LEGENDARY, "textures/items/leather_helmet"));
        $this->add(new CosmeticDefinition("cacti_shoots", CosmeticCategory::HAT, "Cacti Shoots", 80000, CosmeticRarity::COMMON, "textures/items/leather_helmet"));
        $this->add(new CosmeticDefinition("cowboy", CosmeticCategory::HAT, "Cowboy Hat", 90000, CosmeticRarity::COMMON, "textures/items/leather_helmet"));
        $this->add(new CosmeticDefinition("cussy", CosmeticCategory::HAT, "Cussy", 180000, CosmeticRarity::RARE, "textures/items/leather_helmet"));
        $this->add(new CosmeticDefinition("cussycolor", CosmeticCategory::HAT, "Cussy Color", 190000, CosmeticRarity::RARE, "textures/items/leather_helmet"));
        $this->add(new CosmeticDefinition("ember_hat", CosmeticCategory::HAT, "Ember Hat", 200000, CosmeticRarity::RARE, "textures/items/leather_helmet"));
        $this->add(new CosmeticDefinition("ent_hat", CosmeticCategory::HAT, "Ent Hat", 210000, CosmeticRarity::RARE, "textures/items/leather_helmet"));
        $this->add(new CosmeticDefinition("evoc_hat", CosmeticCategory::HAT, "Evoker Hat", 220000, CosmeticRarity::RARE, "textures/items/leather_helmet"));
        $this->add(new CosmeticDefinition("foreigner_hat", CosmeticCategory::HAT, "Foreigner Hat", 100000, CosmeticRarity::COMMON, "textures/items/leather_helmet"));
        $this->add(new CosmeticDefinition("fungus_hat", CosmeticCategory::HAT, "Fungus Hat", 95000, CosmeticRarity::COMMON, "textures/items/leather_helmet"));
        $this->add(new CosmeticDefinition("gasmask", CosmeticCategory::HAT, "Gas Mask", 230000, CosmeticRarity::RARE, "textures/items/leather_helmet"));
        $this->add(new CosmeticDefinition("goldglass", CosmeticCategory::HAT, "Gold Glasses", 420000, CosmeticRarity::LEGENDARY, "textures/items/leather_helmet"));
        $this->add(new CosmeticDefinition("miner_hat", CosmeticCategory::HAT, "Miner Hat", 85000, CosmeticRarity::COMMON, "textures/items/leather_helmet"));
        $this->add(new CosmeticDefinition("mohair", CosmeticCategory::HAT, "Mohair Hat", 90000, CosmeticRarity::COMMON, "textures/items/leather_helmet"));
        $this->add(new CosmeticDefinition("plag", CosmeticCategory::HAT, "Plague Hat", 240000, CosmeticRarity::RARE, "textures/items/leather_helmet"));
        $this->add(new CosmeticDefinition("plaghat", CosmeticCategory::HAT, "Plague Doctor Hat", 450000, CosmeticRarity::LEGENDARY, "textures/items/leather_helmet"));
        $this->add(new CosmeticDefinition("hat_birthday_present", CosmeticCategory::HAT, "Birthday Present", 200000, CosmeticRarity::RARE, "textures/items/leather_helmet"));
        $this->add(new CosmeticDefinition("hat_chicken_jockey", CosmeticCategory::HAT, "Chicken Jockey", 480000, CosmeticRarity::LEGENDARY, "textures/items/leather_helmet"));
        $this->add(new CosmeticDefinition("hat_boombox", CosmeticCategory::HAT, "Boombox", 250000, CosmeticRarity::RARE, "textures/items/leather_helmet"));
        $this->add(new CosmeticDefinition("hat_crown_cake", CosmeticCategory::HAT, "Crown Cake", 500000, CosmeticRarity::LEGENDARY, "textures/items/leather_helmet"));
        $this->add(new CosmeticDefinition("hat_jester", CosmeticCategory::HAT, "Jester Hat", 260000, CosmeticRarity::RARE, "textures/items/leather_helmet"));
        $this->add(new CosmeticDefinition("hat_party", CosmeticCategory::HAT, "Party Hat", 110000, CosmeticRarity::COMMON, "textures/items/leather_helmet"));
        $this->add(new CosmeticDefinition("hat_propeller", CosmeticCategory::HAT, "Propeller Hat", 120000, CosmeticRarity::COMMON, "textures/items/leather_helmet"));
    }

    private function add(CosmeticDefinition $def): void{
        $this->items[$def->getCategory()->value][$def->getKey()] = $def;
    }

    /** @return CosmeticDefinition[] */
    public function all(CosmeticCategory $category): array{
        return array_values($this->items[$category->value] ?? []);
    }

    public function get(CosmeticCategory $category, string $key): ?CosmeticDefinition{
        return $this->items[$category->value][$key] ?? null;
    }
}