<?php

declare(strict_types=1);

namespace AntiServer;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\TextFormat;
use function array_filter;
use function array_map;
use function array_unique;
use function implode;
use function is_array;
use function is_string;
use function mb_strlen;
use function mb_strtolower;
use function preg_match;
use function preg_quote;
use function preg_replace;
use function trim;

final class Main extends PluginBase implements Listener{

	/** Regex matching the blocked words in the (lower-cased) message, or null when no words are configured. */
	private ?string $regex = null;
	/** Same, but for the message with every space/symbol removed (strip-separators). */
	private ?string $compactRegex = null;

	private bool $useBypass = true;
	private bool $logBlocked = false;
	private string $blockedMessage = "";

	protected function onEnable() : void{
		$this->saveDefaultConfig();
		$config = $this->getConfig();

		$words = $config->get("blocked-words", []);
		$words = is_array($words) ? $words : [];
		$words = array_unique(array_filter(
			array_map(static fn($w) => is_string($w) ? trim(mb_strtolower($w)) : "", $words),
			static fn(string $w) => $w !== ""
		));

		if($words !== []){
			// Compiled once; PCRE caches it, so each chat message costs a single preg_match().
			$this->regex = "~" . implode("|", array_map(static fn(string $w) => preg_quote($w, "~"), $words)) . "~u";

			if((bool) $config->get("strip-separators", false)){
				$compact = [];
				foreach($words as $w){
					$c = self::compact($w);
					// Very short words would match inside normal text once separators are removed.
					if(mb_strlen($c) >= 4){
						$compact[] = preg_quote($c, "~");
					}
				}
				if($compact !== []){
					$this->compactRegex = "~" . implode("|", array_unique($compact)) . "~u";
				}
			}
		}

		$this->useBypass = (bool) $config->get("use-bypass-permission", true);
		$this->logBlocked = (bool) $config->get("log-blocked", false);
		$this->blockedMessage = (string) $config->get("message", "");

		$this->getServer()->getPluginManager()->registerEvents($this, $this);
	}

	/**
	 * @priority LOWEST
	 */
	public function onChat(PlayerChatEvent $event) : void{
		if($this->regex === null){
			return;
		}
		$player = $event->getPlayer();
		if($this->useBypass && $player->hasPermission("antiserver.bypass")){
			return;
		}

		// Remove colour codes and zero-width characters so "hy§rpixel" can't slip through.
		$msg = TextFormat::clean($event->getMessage());
		$msg = preg_replace('/[\x{200B}-\x{200D}\x{2060}\x{FEFF}]/u', "", $msg) ?? $msg;
		$msg = mb_strtolower($msg);

		$hit = preg_match($this->regex, $msg) === 1;
		if(!$hit && $this->compactRegex !== null){
			$hit = preg_match($this->compactRegex, self::compact($msg)) === 1;
		}
		if(!$hit){
			return;
		}

		$event->cancel();
		if($this->blockedMessage !== ""){
			$player->sendMessage($this->blockedMessage);
		}
		if($this->logBlocked){
			$this->getLogger()->info("Blocked message from " . $player->getName() . ": " . $event->getMessage());
		}
	}

	/** Lower-cases and removes everything that is not a letter or a digit. */
	private static function compact(string $text) : string{
		return preg_replace('/[^\p{L}\p{N}]+/u', "", mb_strtolower($text)) ?? "";
	}
}
