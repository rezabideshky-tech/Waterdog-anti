<?php

declare(strict_types=1);

namespace AntiServer;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\server\CommandEvent;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\TextFormat;
use function array_filter;
use function array_map;
use function array_unique;
use function count;
use function explode;
use function implode;
use function in_array;
use function is_array;
use function is_string;
use function mb_strlen;
use function mb_strtolower;
use function preg_match;
use function preg_quote;
use function preg_replace;
use function preg_split;
use function str_contains;
use function str_replace;
use function strtolower;
use function trim;

final class Main extends PluginBase implements Listener{

	private const MONITORED_COMMANDS = [
		"msg", "tell", "w", "whisper", "pm", "dm", "r", "reply", "me", "say"
	];

	/** Regex matching the blocked words in the (lower-cased) message, or null when no words are configured. */
	private ?string $regex = null;
	/** Same, but for the message with every space/symbol removed (strip-separators). */
	private ?string $compactRegex = null;

	private bool $useBypass = true;
	private bool $checkCommands = true;
	private bool $logBlocked = true;
	private bool $notifyStaff = true;
	private string $blockedMessage = "";
	private string $staffMessage = "";

	protected function onEnable() : void{
		$this->saveDefaultConfig();
		$config = $this->getConfig();

		$words = $config->get("blocked-words", []);
		$words = is_array($words) ? $words : [];
		$words = array_unique(array_filter(
			array_map(static fn($w) => is_string($w) ? trim(mb_strtolower($w)) : "", $words),
			static fn(string $w) => $w !== ""
		));

		if($words !== []){
			// Compiled once; PCRE caches it, so each chat message costs a single preg_match().
			$this->regex = "~" . implode("|", array_map(static fn(string $w) => preg_quote($w, "~"), $words)) . "~u";

			if((bool) $config->get("strip-separators", true)){
				$compact = [];
				foreach($words as $w){
					$c = self::compact($w);
					// Very short words would match inside normal text once separators are removed.
					if(mb_strlen($c) >= 4){
						$compact[] = preg_quote($c, "~");
					}
				}
				if($compact !== []){
					$this->compactRegex = "~" . implode("|", array_unique($compact)) . "~u";
				}
			}
		}

		$this->useBypass = (bool) $config->get("use-bypass-permission", true);
		$this->checkCommands = (bool) $config->get("check-commands", true);
		$this->logBlocked = (bool) $config->get("log-blocked", true);
		$this->notifyStaff = (bool) $config->get("notify-staff", true);
		$this->blockedMessage = (string) $config->get("message", "§f§l•| §c§lAntiServer §f§l|• §r§cYour message was blocked: advertising or mentioning other servers is not allowed!");
		$this->staffMessage = (string) $config->get("staff-message", "§f§l•| §c§lAntiServer §f§l|• §r§e{player} §7tried to mention a blocked server: §c{message}");

		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->getLogger()->info("§aAntiServers v" . $this->getDescription()->getVersion() . " enabled successfully.");
	}

	/**
	 * @priority LOWEST
	 */
	public function onChat(PlayerChatEvent $event) : void{
		if($this->regex === null){
			return;
		}
		$player = $event->getPlayer();
		if($this->useBypass && $player->hasPermission("antiserver.bypass")){
			return;
		}

		if($this->containsBlockedWord($event->getMessage())){
			$event->cancel();
			$this->handleBlocked($player, $event->getMessage());
		}
	}

	/**
	 * @priority LOWEST
	 */
	public function onCommand(CommandEvent $event) : void{
		if(!$this->checkCommands || $this->regex === null){
			return;
		}
		$sender = $event->getSender();
		if(!$sender instanceof Player){
			return;
		}
		if($this->useBypass && $sender->hasPermission("antiserver.bypass")){
			return;
		}

		$cmdLine = trim($event->getCommand());
		if($cmdLine === ""){
			return;
		}
		$parts = preg_split('/\s+/', $cmdLine, 2);
		if($parts === false || count($parts) < 2){
			return;
		}

		$cmdName = strtolower(trim($parts[0], "/"));
		if(str_contains($cmdName, ":")){
			$sub = explode(":", $cmdName);
			$cmdName = $sub[count($sub) - 1];
		}

		if(!in_array($cmdName, self::MONITORED_COMMANDS, true)){
			return;
		}

		if($this->containsBlockedWord($parts[1])){
			$event->cancel();
			$this->handleBlocked($sender, "/" . $cmdLine);
		}
	}

	private function containsBlockedWord(string $rawText) : bool{
		// Remove colour codes and zero-width characters so "hy§rpixel" can't slip through.
		$msg = TextFormat::clean($rawText);
		$msg = preg_replace('/[\x{200B}-\x{200D}\x{2060}\x{FEFF}]/u', "", $msg) ?? $msg;
		$msg = mb_strtolower($msg);

		$hit = $this->regex !== null && preg_match($this->regex, $msg) === 1;
		if(!$hit && $this->compactRegex !== null){
			$hit = preg_match($this->compactRegex, self::compact($msg)) === 1;
		}
		return $hit;
	}

	private function handleBlocked(Player $player, string $rawContent) : void{
		if($this->blockedMessage !== ""){
			$player->sendMessage($this->blockedMessage);
		}
		if($this->notifyStaff && $this->staffMessage !== ""){
			$alert = str_replace(
				["{player}", "{message}"],
				[$player->getName(), TextFormat::clean($rawContent)],
				$this->staffMessage
			);
			foreach($this->getServer()->getOnlinePlayers() as $online){
				if($online->hasPermission("antiserver.bypass")){
					$online->sendMessage($alert);
				}
			}
		}
		if($this->logBlocked){
			$this->getLogger()->info("Blocked server advertisement from " . $player->getName() . ": " . TextFormat::clean($rawContent));
		}
	}

	/** Lower-cases and removes everything that is not a letter or a digit. */
	private static function compact(string $text) : string{
		return preg_replace('/[^\p{L}\p{N}]+/u', "", mb_strtolower($text)) ?? "";
	}
}
