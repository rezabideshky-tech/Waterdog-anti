<?php

declare(strict_types=1);

namespace AntiGlitch;

use pocketmine\block\Door;
use pocketmine\block\FenceGate;
use pocketmine\block\Trapdoor;
use pocketmine\command\CommandSender;
use pocketmine\entity\projectile\EnderPearl;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\entity\EntityTeleportEvent;
use pocketmine\event\entity\ProjectileHitBlockEvent;
use pocketmine\event\entity\ProjectileHitEntityEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\server\CommandEvent;
use pocketmine\math\AxisAlignedBB;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\world\Position;
use pocketmine\world\World;
use function count;
use function is_string;
use function max;
use function sqrt;
use function strlen;

/**
 * Optimised rewrite of AntiGlitch for PocketMine-MP 5.
 *
 * - Every setting is read once on enable (no Config lookups while the server runs).
 * - Handlers return immediately when their feature is off or when the event isn't relevant,
 *   and the heavy work (collision checks / teleports) only ever happens on an actual glitch.
 */
final class Main extends PluginBase implements Listener{

	/** Horizontal push-out distances tried when a player would end up inside a block. */
	private const PUSH_STEPS = [0.3, 0.5, 0.7, 0.9, 1.1];
	/** Vertical offsets tried afterwards (negative = lower, positive = raise). */
	private const LIFTS = [-0.5, -1.0, -1.8, 0.25, 0.5];
	/** Minimum ticks between two re-syncs of the same player (stops spam while holding right-click). */
	private const FIX_COOLDOWN_TICKS = 5;

	private bool $cancelNoSpace = false;
	private bool $placeFix = true;
	private bool $breakFix = true;
	private bool $doorFix = true;
	private bool $commandFix = true;

	private ?string $msgPearl = null;
	private ?string $msgPlace = null;
	private ?string $msgBreak = null;
	private ?string $msgDoor = null;
	private ?string $msgCommand = null;

	/** @var array<int, int> player entity id => server tick of their last ender pearl impact */
	private array $pearlTick = [];
	/** @var array<int, int> player entity id => server tick of the last re-sync */
	private array $lastFix = [];

	protected function onEnable() : void{
		$this->saveDefaultConfig();
		$c = $this->getConfig();

		$this->cancelNoSpace = (bool) $c->get("Prevent-Pearling-In-Small-Areas", false);
		$this->placeFix = (bool) $c->get("Prevent-Place-Block-Glitching", true);
		$this->breakFix = (bool) $c->get("Prevent-Break-Block-Glitching", true);
		$this->doorFix = (bool) $c->get("Prevent-Open-Door-Glitching", true);
		$this->commandFix = (bool) $c->get("Prevent-Command-Glitching", true);

		$this->msgPearl = self::message($c->get("CancelPearl-Message", false));
		$this->msgPlace = self::message($c->get("CancelBlockPlace-Message", false));
		$this->msgBreak = self::message($c->get("CancelBlockBreak-Message", false));
		$this->msgDoor = self::message($c->get("CancelOpenDoor-Message", false));
		$this->msgCommand = self::message($c->get("CancelCommand-Message", false));

		$this->getServer()->getPluginManager()->registerEvents($this, $this);
	}

	private static function message(mixed $value) : ?string{
		return is_string($value) && $value !== "" ? $value : null;
	}

	public function onQuit(PlayerQuitEvent $event) : void{
		$id = $event->getPlayer()->getId();
		unset($this->pearlTick[$id], $this->lastFix[$id]);
	}

	// ------------------------------------------------------------------ ender pearls

	public function onPearlHitBlock(ProjectileHitBlockEvent $event) : void{
		$this->markPearl($event->getEntity());
	}

	public function onPearlHitEntity(ProjectileHitEntityEvent $event) : void{
		$this->markPearl($event->getEntity());
	}

	private function markPearl(object $projectile) : void{
		if($projectile instanceof EnderPearl){
			$owner = $projectile->getOwningEntity();
			if($owner instanceof Player){
				// PocketMine teleports the owner during the very same tick the pearl lands.
				$this->pearlTick[$owner->getId()] = $this->getServer()->getTick();
			}
		}
	}

	/**
	 * @priority HIGH
	 */
	public function onTeleport(EntityTeleportEvent $event) : void{
		$player = $event->getEntity();
		if(!$player instanceof Player){
			return;
		}
		$id = $player->getId();
		if(!isset($this->pearlTick[$id])){
			return;
		}
		$isPearl = $this->pearlTick[$id] === $this->getServer()->getTick();
		unset($this->pearlTick[$id]);
		if(!$isPearl){
			return;
		}

		$to = $event->getTo();
		$world = $to->getWorld();
		$box = $player->getBoundingBox();
		$halfWidth = $box->getXLength() / 2;
		$height = $box->getYLength();

		$x = (float) $to->x;
		$y = (float) $to->y;
		$z = (float) $to->z;
		if(!$this->collides($world, $x, $y, $z, $halfWidth, $height)){
			return; // landing spot is fine
		}

		// Prefer pushing the player back towards where they threw from, so they never end up behind a wall.
		$from = $event->getFrom();
		$safe = $this->findFreeSpot($world, $x, $y, $z, (float) $from->x, (float) $from->z, $halfWidth, $height);
		if($safe === null){
			if($this->cancelNoSpace){
				$event->cancel();
				$this->send($player, $this->msgPearl);
			}
			return;
		}
		$event->setTo(new Position($safe[0], $safe[1], $safe[2], $world));
	}

	// ------------------------------------------------------------------ blocks

	/**
	 * @priority MONITOR
	 * @handleCancelled
	 */
	public function onBlockPlace(BlockPlaceEvent $event) : void{
		if(!$this->placeFix || !$event->isCancelled()){
			return;
		}
		$player = $event->getPlayer();
		if($player->isCreative() || $player->isSpectator()){
			return;
		}
		$pos = $event->getBlockReplaced()->getPosition();
		if(!$this->isUnderFeet($player, (float) $pos->getFloorX(), (float) $pos->getFloorZ(), (float) $pos->getFloorY() + 1.0)){
			return;
		}
		if($this->cooledDown($player)){
			$pos->getWorld()->sendBlocks([$player], [$pos]);
			$player->teleport($player->getLocation());
			$this->send($player, $this->msgPlace);
		}
	}

	/**
	 * @priority MONITOR
	 * @handleCancelled
	 */
	public function onBlockBreak(BlockBreakEvent $event) : void{
		if(!$this->breakFix || !$event->isCancelled()){
			return;
		}
		$player = $event->getPlayer();
		if($player->isCreative() || $player->isSpectator()){
			return;
		}
		$block = $event->getBlock();
		$pos = $block->getPosition();
		$top = (float) $pos->getFloorY() + 1.0;
		$boxes = $block->getCollisionBoxes();
		if($boxes !== []){
			$top = $boxes[0]->maxY;
			foreach($boxes as $bb){
				$top = max($top, $bb->maxY);
			}
		}
		if(!$this->isUnderFeet($player, (float) $pos->getFloorX(), (float) $pos->getFloorZ(), $top)){
			return;
		}
		if($this->cooledDown($player)){
			$pos->getWorld()->sendBlocks([$player], [$pos]);
			$loc = $player->getLocation();
			// Put the player back on top of the block that is still there.
			$player->teleport(new Position($loc->x, $top, $loc->z, $loc->getWorld()), $loc->yaw, $loc->pitch);
			$this->send($player, $this->msgBreak);
		}
	}

	/**
	 * @priority MONITOR
	 * @handleCancelled
	 */
	public function onInteract(PlayerInteractEvent $event) : void{
		if(!$this->doorFix || !$event->isCancelled()){
			return;
		}
		$block = $event->getBlock();
		if(!($block instanceof Door || $block instanceof FenceGate || $block instanceof Trapdoor)){
			return;
		}
		$player = $event->getPlayer();
		if($player->isCreative() || $player->isSpectator()){
			return;
		}

		$loc = $player->getLocation();
		$world = $loc->getWorld();
		$box = $player->getBoundingBox();
		$halfWidth = $box->getXLength() / 2;
		$height = $box->getYLength();
		$x = (float) $loc->x;
		$y = (float) $loc->y;
		$z = (float) $loc->z;

		// Only act when the player is really inside the door / gate / trapdoor.
		if(!$this->collides($world, $x, $y, $z, $halfWidth, $height)){
			return;
		}
		if(!$this->cooledDown($player)){
			return;
		}

		// "Origin" is chosen on the far side of the player from the block, so they are pushed away from it.
		$bp = $block->getPosition();
		$ox = 2 * $x - ($bp->getFloorX() + 0.5);
		$oz = 2 * $z - ($bp->getFloorZ() + 0.5);
		$safe = $this->findFreeSpot($world, $x, $y, $z, $ox, $oz, $halfWidth, $height);
		if($safe !== null){
			$player->teleport(new Position($safe[0], $safe[1], $safe[2], $world), $loc->yaw, $loc->pitch);
			$this->send($player, $this->msgDoor);
		}
	}

	// ------------------------------------------------------------------ commands

	/**
	 * @priority LOWEST
	 */
	public function onCommand(CommandEvent $event) : void{
		if(!$this->commandFix || !$event->getSender() instanceof Player){
			return;
		}
		// The command line arrives without its leading "/".
		$cmd = $event->getCommand();
		$len = strlen($cmd);
		if($len === 0){
			return;
		}
		$first = $cmd[0];
		if($first === " " || $first === "\\" || $first === "\"" || $cmd[$len - 1] === "\\"){
			$event->cancel();
			$this->send($event->getSender(), $this->msgCommand);
		}
	}

	// ------------------------------------------------------------------ helpers

	private function send(CommandSender $target, ?string $message) : void{
		if($message !== null){
			$target->sendMessage($message);
		}
	}

	/** Returns true (and records the tick) when this player may be re-synced again. */
	private function cooledDown(Player $player) : bool{
		$id = $player->getId();
		$tick = $this->getServer()->getTick();
		if(isset($this->lastFix[$id]) && $tick - $this->lastFix[$id] < self::FIX_COOLDOWN_TICKS){
			return false;
		}
		$this->lastFix[$id] = $tick;
		return true;
	}

	/**
	 * True when the player stands on (or just above) a block column: they overlap it horizontally and their
	 * feet are within a small distance of its top.
	 */
	private function isUnderFeet(Player $player, float $bx, float $bz, float $top) : bool{
		$loc = $player->getLocation();
		$hw = $player->getBoundingBox()->getXLength() / 2;
		$px = $loc->x;
		$pz = $loc->z;
		if($px + $hw <= $bx || $px - $hw >= $bx + 1.0 || $pz + $hw <= $bz || $pz - $hw >= $bz + 1.0){
			return false;
		}
		$dy = $loc->y - $top;
		return $dy >= -0.05 && $dy <= 0.6;
	}

	/** Whether a player-sized box centred at (x, z) with its feet at y overlaps any block. */
	private function collides(World $world, float $x, float $y, float $z, float $halfWidth, float $height) : bool{
		// Shrunk by a hair so standing exactly on a block / next to a wall doesn't count as a collision.
		$e = 0.001;
		return count($world->getBlockCollisionBoxes(new AxisAlignedBB(
			$x - $halfWidth + $e, $y + $e, $z - $halfWidth + $e,
			$x + $halfWidth - $e, $y + $height - $e, $z + $halfWidth - $e
		))) > 0;
	}

	/**
	 * Finds the closest free position for a player-sized box, or null when there is none nearby.
	 * Tries (1) pushing horizontally, first towards ($ox, $oz), then along the 4 axes, then
	 * (2) small vertical offsets. At most ~30 cheap collision checks, and only when a glitch happened.
	 *
	 * @return float[]|null [x, y, z]
	 */
	private function findFreeSpot(World $world, float $x, float $y, float $z, float $ox, float $oz, float $halfWidth, float $height) : ?array{
		$dirs = [];
		$dx = $ox - $x;
		$dz = $oz - $z;
		$len = sqrt($dx * $dx + $dz * $dz);
		if($len > 0.0001){
			$dirs[] = [$dx / $len, $dz / $len];
		}
		$dirs[] = [1.0, 0.0];
		$dirs[] = [-1.0, 0.0];
		$dirs[] = [0.0, 1.0];
		$dirs[] = [0.0, -1.0];

		foreach(self::PUSH_STEPS as $step){
			foreach($dirs as [$ux, $uz]){
				$nx = $x + $ux * $step;
				$nz = $z + $uz * $step;
				if(!$this->collides($world, $nx, $y, $nz, $halfWidth, $height)){
					return [$nx, $y, $nz];
				}
			}
		}
		foreach(self::LIFTS as $lift){
			if(!$this->collides($world, $x, $y + $lift, $z, $halfWidth, $height)){
				return [$x, $y + $lift, $z];
			}
		}
		return null;
	}
}
