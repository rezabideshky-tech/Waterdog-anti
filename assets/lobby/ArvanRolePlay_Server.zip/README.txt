ArvanGaming RolePlay - Drivable Truck (PocketMine-MP 5)
1) Put resource_packs/ArvanLobby_RP.zip in your RolePlay server's resource_packs/ folder.
   resource_packs.yml:
     force_resources: true
     resource_stack:
       - ArvanLobby_RP.zip
2) Install Customies (poggit.pmmp.io/p/Customies) and copy plugins/ArvanVehicles into plugins/.
3) Restart.
In-game (op):  /truck spawn   |   /truck remove
Players: tap the truck to get in, W/S = gas/reverse, A/D = steer, Sneak (or dismount button) = get out.
Tune speed, steering and seat position in plugins/ArvanVehicles/config.yml.
--- RESOURCE PACK PROTECTION ---
The pack is ENCRYPTED. Keep resource_packs/ArvanLobby_RP.zip.key next to the zip (PocketMine reads it
automatically). Never share the .key file. plugins/ArvanPackGuard bans accounts/IPs that download the
packs without joining (pack stealers). Admin: /packguard status | list | unban <xuid|ip|name>
Check a stolen texture for the hidden ArvanGaming watermark:  python3 protect_pack.py --check texture.png
