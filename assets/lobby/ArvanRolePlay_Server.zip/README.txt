ArvanGaming RolePlay - Drivable Truck (PocketMine-MP 5)
1) Put resource_packs/ArvanGaming_Pack.zip in your RolePlay server's resource_packs/ folder.
   resource_packs.yml:
     force_resources: true
     resource_stack:
       - ArvanGaming_Pack.zip
2) Install Customies (poggit.pmmp.io/p/Customies) and copy plugins/ArvanVehicles into plugins/.
3) Restart.
In-game (op):  /truck spawn   |   /truck remove
Players: tap the truck to get in, W/S = gas/reverse, A/D = steer, Sneak (or dismount button) = get out.
Tune speed, steering and seat position in plugins/ArvanVehicles/config.yml.
NOTE: plain (NOT encrypted) pack. Delete old ArvanLobby_RP.zip and ArvanLobby_RP.zip.key from resource_packs/.
