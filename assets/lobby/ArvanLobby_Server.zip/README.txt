ArvanGaming Lobby + Battle Pass - PocketMine-MP 5
ONE resource pack contains everything (BedWars Duos, RolePlay City, Cargo Truck, Battle Pass).
1) Remove old packs (BedWarsBattlePass_RP.zip / old ArvanLobby_RP.zip) from resource_packs/.
2) Put resource_packs/ArvanLobby_RP.zip in resource_packs/. In resource_packs.yml:
     force_resources: true
     resource_stack:
       - ArvanLobby_RP.zip
3) Install Customies (poggit.pmmp.io/p/Customies), copy plugins/ArvanLobby and plugins/BedWarsBattlePass into plugins/.
4) Restart, edit plugins/ArvanLobby/config.yml (address/port) -> restart.
Commands (op): /lobbynpc spawn duos | /lobbynpc spawn roleplay | /lobbynpc spawn truck | /lobbynpc spawn skyblock | /lobbynpc remove
               /battlepass spawn | /battlepass remove
--- RESOURCE PACK PROTECTION ---
Pack is NOT encrypted (plain zip). Delete any old ArvanLobby_RP.zip.key from resource_packs/!
plugins/ArvanPackGuard bans accounts/IPs that download the
packs without joining (pack stealers). Admin: /packguard status | list | unban <xuid|ip|name>
(Encrypted + watermarked build: ENCRYPT=1 ./build_bundles.sh)
