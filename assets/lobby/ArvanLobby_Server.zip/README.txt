ArvanGaming Lobby NPCs - PocketMine-MP 5
1) Put resource_packs/ArvanLobby_RP.zip in your server's resource_packs/ folder.
   resource_packs.yml:
     force_resources: true
     resource_stack:
       - ArvanLobby_RP.zip
2) Install Customies (poggit.pmmp.io/p/Customies) and copy plugins/ArvanLobby into plugins/.
3) Restart, edit plugins/ArvanLobby/config.yml (server address/port or command) -> restart.
4) In-game (op):  /lobbynpc spawn duos   |   /lobbynpc spawn roleplay   |   /lobbynpc remove
