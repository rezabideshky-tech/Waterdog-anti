<?php

declare(strict_types=1);

namespace sergittos\bedwars\cosmetics\wearable\hats;

use customiesdevs\customies\item\CreativeInventoryInfo;
use customiesdevs\customies\item\ItemComponents;
use customiesdevs\customies\item\ItemComponentsTrait;
use pocketmine\inventory\ArmorInventory;
use pocketmine\item\Armor;
use pocketmine\item\ArmorTypeInfo;
use pocketmine\item\ItemIdentifier;

/**
 * Single generic cosmetic-hat armor item, used to register EVERY cosmetic
 * hat. Purely visual - see HatWearService for how it is kept from ever
 * overriding real BedWars team armor in-game.
 *
 * This replaces what used to be one hand-written PHP class per hat (23 of
 * them). The actual model/texture that renders on the player's head comes
 * entirely from the bundled Hats.zip resource pack, matched client-side by
 * "component tag" - never from PHP - so this one class can serve every hat.
 * Adding a new hat is now a pure data change:
 *   1. Add its id/name/price/rarity to CosmeticsRegistry (cosmetics.yml).
 *   2. Map its key to a Customies identifier in HatCatalog.
 *   3. Drop the matching attachable into resources/Hats.zip.
 * No new PHP class is needed for step 3 onward - HatItemRegistrar below
 * loops over HatCatalog and registers this same class for every entry.
 */
final class CosmeticHatItem extends Armor implements ItemComponents{
	use ItemComponentsTrait;

	/**
	 * Component tag for the NEXT hat about to be registered. Customies'
	 * registerItem() constructs the item class synchronously (no threads,
	 * no queuing) the moment it's called, so setting this immediately
	 * before each registerItem() call and reading it here is safe and
	 * deterministic - see HatItemRegistrar::register().
	 */
	public static ?string $pendingComponentTag = null;

	public function __construct(ItemIdentifier $identifier, string $name = "Hat"){
		parent::__construct($identifier, $name, new ArmorTypeInfo(0, 1, ArmorInventory::SLOT_HEAD, 0, true));
		$tag = self::$pendingComponentTag ?? "customies_hat";
		$this->initComponent($tag, new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_NONE));
	}
}
