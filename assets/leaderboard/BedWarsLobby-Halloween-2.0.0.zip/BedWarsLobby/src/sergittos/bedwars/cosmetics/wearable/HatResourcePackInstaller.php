<?php

declare(strict_types=1);

namespace sergittos\bedwars\cosmetics\wearable;

use pocketmine\plugin\Plugin;
use pocketmine\resourcepacks\ZippedResourcePack;
use ReflectionClass;

/**
 * Force-merges the bundled "Hats" resource pack (attachable geometry for
 * every cosmetic hat) into the server's resource pack list and forces the
 * client to accept it, the same way the original HatsPlusPM plugin does.
 * If your server already ships its own combined resource pack, merge the
 * contents of resources/Hats.mcpack into it instead and skip calling this.
 */
final class HatResourcePackInstaller{

    private static bool $installed = false;

    public static function install(Plugin $plugin): void{
        if(self::$installed){
            return;
        }
        self::$installed = true;

        $plugin->saveResource("Hats.zip", true);

        $manager = $plugin->getServer()->getResourcePackManager();
        $pack = new ZippedResourcePack($plugin->getDataFolder() . "Hats.zip");

        $reflection = new ReflectionClass($manager);

        $packs = $reflection->getProperty("resourcePacks");
        $packs->setAccessible(true);
        $current = $packs->getValue($manager);
        $current[] = $pack;
        $packs->setValue($manager, $current);

        $uuids = $reflection->getProperty("uuidList");
        $uuids->setAccessible(true);
        $currentUuids = $uuids->getValue($manager);
        $currentUuids[strtolower($pack->getPackId())] = $pack;
        $uuids->setValue($manager, $currentUuids);

        $forced = $reflection->getProperty("serverForceResources");
        $forced->setAccessible(true);
        $forced->setValue($manager, true);
    }
}
