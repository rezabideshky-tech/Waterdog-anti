<?php

declare(strict_types=1);

namespace sergittos\bedwars\cosmetics\wearable;

use customiesdevs\customies\item\CustomiesItemFactory;
use pocketmine\plugin\Plugin;
use sergittos\bedwars\cosmetics\registry\CosmeticCategory;
use sergittos\bedwars\cosmetics\registry\CosmeticsRegistry;
use sergittos\bedwars\cosmetics\wearable\hats\CosmeticHatItem;
use function class_exists;
use function ucwords;
use function str_replace;

/**
 * Registers every cosmetic hat from HatCatalog as a Customies custom armor
 * item, using the single generic CosmeticHatItem class for all of them.
 * Must run from a plugin that loads AFTER Customies (BedWarsLobby /
 * BedWarsGame both load POSTWORLD, same as Customies' default, and both
 * softdepend on it - see their plugin.yml). If Customies isn't
 * installed/enabled, this simply logs a warning and hats stay disabled
 * without affecting anything else.
 *
 * Fully data-driven: to add a new hat, add it to HatCatalog and
 * CosmeticsRegistry - nothing here needs to change.
 */
final class HatItemRegistrar{

    private static bool $registered = false;

    public static function register(Plugin $plugin): void{
        if(self::$registered){
            return;
        }

        if(!class_exists(CustomiesItemFactory::class)){
            $plugin->getLogger()->warning(
                "Customies plugin not found - cosmetic Hats will not be available. " .
                "Install Customies (softdepend) to enable them."
            );
            return;
        }

        try{
            HatResourcePackInstaller::install($plugin);

            $factory = CustomiesItemFactory::getInstance();
            foreach(HatCatalog::all() as $key => $identifier){
                $def = CosmeticsRegistry::getInstance()->get(CosmeticCategory::HAT, $key);
                $name = $def?->getDisplayName() ?? ucwords(str_replace(["_", "-"], " ", $key));

                CosmeticHatItem::$pendingComponentTag = HatCatalog::componentTagFor($identifier);
                $factory->registerItem(CosmeticHatItem::class, $identifier, $name);
            }
            CosmeticHatItem::$pendingComponentTag = null;

            self::$registered = true;
        }catch(\Throwable $e){
            $plugin->getLogger()->error("Failed to register cosmetic Hats: " . $e->getMessage());
        }
    }
}
