<?php

declare(strict_types=1);

namespace sergittos\bedwars\lobby\clan;

use pocketmine\plugin\Plugin;
use pocketmine\resourcepacks\ZippedResourcePack;
use ReflectionClass;

/**
 * Force-merges the bundled "ClanCrests" resource pack (textures/ui/icon_r*_c*_*.png,
 * used as clan crest icons in the crest picker GUI - see ClanCrestRegistry) into the
 * server's resource pack list and forces the client to accept it, the same way
 * HatResourcePackInstaller does for cosmetic hats. If your server already ships its
 * own combined resource pack, merge the contents of resources/ClanCrests.zip into it
 * instead and skip calling this.
 */
final class ClanCrestResourcePackInstaller{

    private static bool $installed = false;

    public static function install(Plugin $plugin): void{
        if(self::$installed){
            return;
        }
        self::$installed = true;

        $plugin->saveResource("ClanCrests.zip", true);

        $manager = $plugin->getServer()->getResourcePackManager();
        $pack = new ZippedResourcePack($plugin->getDataFolder() . "ClanCrests.zip");

        $reflection = new ReflectionClass($manager);

        $packs = $reflection->getProperty("resourcePacks");
        $packs->setAccessible(true);
        $current = $packs->getValue($manager);
        $current[] = $pack;
        $packs->setValue($manager, $current);

        $uuids = $reflection->getProperty("uuidList");
        $uuids->setAccessible(true);
        $currentUuids = $uuids->getValue($manager);
        $currentUuids[strtolower($pack->getPackId())] = $pack;
        $uuids->setValue($manager, $currentUuids);

        $forced = $reflection->getProperty("serverForceResources");
        $forced->setAccessible(true);
        $forced->setValue($manager, true);
    }
}
