<?php

declare(strict_types=1);

namespace sergittos\bedwars\lobby\profile;

use pocketmine\plugin\Plugin;
use pocketmine\resourcepacks\ZippedResourcePack;
use ReflectionClass;
use function strtolower;

/**
 * Force-merges the bundled "BedWars Profile UI" resource pack (the purple full-screen profile / rank / medals /
 * achievements screens) into the server's resource pack list and forces the client to accept it - the exact same
 * way LockerIconResourcePackInstaller does for the cosmetics icons.
 *
 * If your server already ships one combined resource pack, merge resources/BedWarsProfileUI.zip into it instead
 * (careful with ui/server_form.json - see README_PROFILE.md) and skip calling this.
 *
 * Only needed on the Lobby server - the profile forms are only ever opened there.
 */
final class ProfileUiResourcePackInstaller{

    private static bool $installed = false;

    public static function install(Plugin $plugin) : void{
        if(self::$installed){
            return;
        }
        self::$installed = true;

        $plugin->saveResource("BedWarsProfileUI.zip", true);

        $manager = $plugin->getServer()->getResourcePackManager();
        $pack = new ZippedResourcePack($plugin->getDataFolder() . "BedWarsProfileUI.zip");

        $reflection = new ReflectionClass($manager);

        $packs = $reflection->getProperty("resourcePacks");
        $packs->setAccessible(true);
        $current = $packs->getValue($manager);
        $current[] = $pack;
        $packs->setValue($manager, $current);

        $uuids = $reflection->getProperty("uuidList");
        $uuids->setAccessible(true);
        $currentUuids = $uuids->getValue($manager);
        $currentUuids[strtolower($pack->getPackId())] = $pack;
        $uuids->setValue($manager, $currentUuids);

        $forced = $reflection->getProperty("serverForceResources");
        $forced->setAccessible(true);
        $forced->setValue($manager, true);
    }
}
