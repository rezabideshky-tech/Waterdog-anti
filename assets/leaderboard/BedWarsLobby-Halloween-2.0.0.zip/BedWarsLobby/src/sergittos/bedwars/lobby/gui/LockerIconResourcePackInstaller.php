<?php

declare(strict_types=1);

namespace sergittos\bedwars\lobby\gui;

use pocketmine\plugin\Plugin;
use pocketmine\resourcepacks\ZippedResourcePack;
use ReflectionClass;

/**
 * Force-merges the bundled "LockerIcons" resource pack (textures/ui/backbling.png,
 * textures/ui/capesicon/*.png, textures/ui/wingsicon/*.png, and a handful of other
 * category button icons - see CosmeticCategory::icon() and the icon paths in
 * CosmeticsRegistry::initDefaults()) into the server's resource pack list and
 * forces the client to accept it, the exact same way ClanCrestResourcePackInstaller
 * does for clan crests. If your server already ships its own combined resource
 * pack, merge the contents of resources/LockerIcons.zip into it instead and skip
 * calling this.
 *
 * Only needed on the Lobby server - CosmeticsGui (the only place these icon paths
 * are ever sent to a client as form button icons) only exists here.
 */
final class LockerIconResourcePackInstaller{

    private static bool $installed = false;

    public static function install(Plugin $plugin): void{
        if(self::$installed){
            return;
        }
        self::$installed = true;

        $plugin->saveResource("LockerIcons.zip", true);

        $manager = $plugin->getServer()->getResourcePackManager();
        $pack = new ZippedResourcePack($plugin->getDataFolder() . "LockerIcons.zip");

        $reflection = new ReflectionClass($manager);

        $packs = $reflection->getProperty("resourcePacks");
        $packs->setAccessible(true);
        $current = $packs->getValue($manager);
        $current[] = $pack;
        $packs->setValue($manager, $current);

        $uuids = $reflection->getProperty("uuidList");
        $uuids->setAccessible(true);
        $currentUuids = $uuids->getValue($manager);
        $currentUuids[strtolower($pack->getPackId())] = $pack;
        $uuids->setValue($manager, $currentUuids);

        $forced = $reflection->getProperty("serverForceResources");
        $forced->setAccessible(true);
        $forced->setValue($manager, true);
    }
}
