<?php
/**
 * سازنده‌ی .phar اختیاری — فقط اگر نسخه‌ی phar می‌خواهی.
 * اجرا (روی سروری که PHP CLI دارد):
 *     php -d phar.readonly=0 build-phar.php
 * خروجی: BedWarsLobby.phar  →  بگذار داخل پوشه‌ی plugins/
 *
 * نکته: PocketMine پلاگین را از حالت پوشه هم لود می‌کند، پس این مرحله لازم نیست.
 */
$name = "BedWarsLobby";
$out  = __DIR__ . "/{$name}.phar";
@unlink($out);

$phar = new Phar($out);
$phar->setSignatureAlgorithm(Phar::SHA1);
$phar->startBuffering();
$phar->buildFromDirectory(__DIR__ . "/{$name}", "#^.*$#");
$phar->setStub('<?php __HALT_COMPILER();');
$phar->stopBuffering();

echo "ساخته شد: {$out} (" . round(filesize($out) / 1024, 1) . " KB)\n";
