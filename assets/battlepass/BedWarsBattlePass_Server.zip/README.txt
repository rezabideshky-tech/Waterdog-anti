BedWars Battle Pass - PocketMine-MP 5
1) Copy resource_packs/BedWarsBattlePass_RP.zip into your server's resource_packs/ folder.
2) In resource_packs.yml set:
     force_resources: true
     resource_stack:
       - BedWarsBattlePass_RP.zip
3) Install the Customies plugin (poggit.pmmp.io/p/Customies), then copy plugins/BedWarsBattlePass into plugins/.
4) Restart, then in-game (op): /battlepass spawn   |   /battlepass remove
Players tap the NPC to open the Battle Pass menu.
